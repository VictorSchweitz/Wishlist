package com.example.demo.wishlistrepo;

import com.example.demo.controller.HomeController;
import com.example.demo.model.WishConstructor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class WishRepo
{
    private static Connection dbConnection;


    public WishRepo()
    {
        try
        {
            dbConnection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/wishlist", "root", "Victor1303002000");
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    public static void printSQLColumn()
    {

        try
        {
            PreparedStatement myStmt = dbConnection.prepareStatement("SELECT * FROM wishes");
            ResultSet rs = myStmt.executeQuery();
            rs.next();
            String wishString = rs.getString("wish");
        }
        catch (Exception e)
        {

        }
    }

    public static void addWishToDatabase(String addWish)
    {


        try
        {
            dbConnection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/wishlist", "root", "Victor1303002000");

            PreparedStatement myStmt = dbConnection.prepareStatement("INSERT INTO wishes VALUES(DEFAULT, ?)");
            myStmt.setString(1, addWish);
            myStmt.executeUpdate();

            dbConnection.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void retrieveWishTableFromDatabase(String retrieveWishTable)
    {
        try
        {
            dbConnection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/wishlist", "root", "Victor1303002000");

            String retrieveTable = "SELECT * FROM wishes";
            Statement retrieveTableStatement = dbConnection.createStatement();
            ResultSet retrieveTableResult = retrieveTableStatement.executeQuery(retrieveTable);

            while (retrieveTableResult.next())
            {
                int wishId = retrieveTableResult.getInt("id");
                String wishName = retrieveTableResult.getString("wish");

                System.out.println(wishId + ", " + wishName);
            }


            dbConnection.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }


    public static ArrayList<WishConstructor> gettingWishes()
    {
        ArrayList<WishConstructor> wishes = new ArrayList<WishConstructor>();

        try
        {
            Connection dbConnection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/wishlist", "root", "Victor1303002000");
            Statement statement = dbConnection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT * FROM wishes");

            while(resultSet.next())
            {
                String wishName = resultSet.getString("wish");
                int id = resultSet.getInt("id");
                WishConstructor wish = new WishConstructor(wishName, id);
                wishes.add(wish);
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

       return wishes;
    }



}

