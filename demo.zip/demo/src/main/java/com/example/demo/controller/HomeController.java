package com.example.demo.controller;

import com.example.demo.model.WishConstructor;
import com.example.demo.model.Wishlist;
import com.example.demo.service.WishService;
import com.example.demo.wishlistrepo.WishRepo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.context.request.WebRequest;

import java.util.ArrayList;

@Controller
public class HomeController
{
    @GetMapping("/")
    public String home(Model model)
    {

        WishRepo.printSQLColumn();

        return "index";
    }

    @GetMapping("/request")
    public String request(Model model)
    {
        return "redirect:/retrievewishes";
    }

    @PostMapping("/addwishes")
    public String addWish(WebRequest webRequest)
    {
        String addWish = webRequest.getParameter("addwishes");
        WishRepo.addWishToDatabase(addWish);
        return "request";
    }

    @GetMapping("/retrievewishes")
    public String retrieveWishes(Model model)
    {
        ArrayList<WishConstructor> wishesFromBoard = WishService.getWishesFromBoard();
        System.out.println(wishesFromBoard);
        model.addAttribute("wishes", wishesFromBoard);
        return "retrievewishes";
    }


}
