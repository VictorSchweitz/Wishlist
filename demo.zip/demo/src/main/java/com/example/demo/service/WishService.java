package com.example.demo.service;

import com.example.demo.model.WishConstructor;
import com.example.demo.wishlistrepo.WishRepo;

import java.util.ArrayList;

public class WishService
{
    WishRepo wishRepo = new WishRepo();


    public static ArrayList<WishConstructor> getWishesFromBoard()
    {
        return WishRepo.gettingWishes();
    }
}
