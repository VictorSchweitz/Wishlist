package com.example.demo.model;

public class Wishlist
{
    public Wishlist() {}


    private String wish;

    // Constructor for a wish
    public Wishlist(String wish)
    {
        this.wish = wish;
    }

    // Getters and setters
    public void setWish(String wish)
    {
        this.wish = wish;
    }

    public String getWish()
    {
        return wish;
    }
}
