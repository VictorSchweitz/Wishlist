package com.example.demo.model;

import java.sql.Connection;
import java.sql.DriverManager;

public class WishConstructor
{
    // Wish constructor
    private String title;
    private int id;

    public WishConstructor(String title, int id)
    {
        this.title = title;
        this.id = id;
    }


    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    @Override
    public String toString()
    {
        return "WishConstructor{" +
                "title='" + title + '\'' +
                ", id=" + id +
                '}';
    }
}
