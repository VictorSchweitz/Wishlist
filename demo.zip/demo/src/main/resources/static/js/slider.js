const modals = document.querySelectorAll('.modal')
const previousBtn = document.getElementById('previous-btn')
const nextBtn = document.getElementById('next-btn')
const modalInputs = document.querySelectorAll('.input')

window.addEventListener('load', () =>
{
    modalInputs.forEach((input) =>
    {
        input.value = ''
    })
})



// Next slide
const nextSlide = () =>
{
    const currentSlide = document.querySelector('.current')

    // Removing the current class from the slide showing
    currentSlide.classList.remove('current')

    // Checking if the current slide has a sibling

    if (currentSlide.nextElementSibling)
    {
        currentSlide.nextElementSibling.classList.add('current')
    }
    else if (!currentSlide.nextElementSibling)
    {
        modals[0].classList.add('current')
    }
}

// Previous slide
const previousSlide = () =>
{
    const currentSlide = document.querySelector('.current')

    currentSlide.classList.remove('current')

    if (currentSlide.previousElementSibling)
    {
        currentSlide.previousElementSibling.classList.add('current')
    }
    else if (!currentSlide.previousElementSibling)
    {
        modals[modals.length - 1].classList.add('current')
    }
}

previousBtn.addEventListener('click', previousSlide)
nextBtn.addEventListener('click', nextSlide)