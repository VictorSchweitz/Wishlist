// Login modal //
const loginModal = document.getElementById('login-modal')
const openModalBtn = document.getElementById('open-modal-btn')
const closeModalBtn = document.getElementById('close-modal-btn')
const loginBtn = document.getElementById('login-btn')
const emailInput = document.getElementById('email-input')
const passwordInput = document.getElementById('password-input')

// Making sure that the input fields are emptied when the page loads initially
window.addEventListener('load', () =>
{
    // Clearing out the input fields on window load
    emailInput.value = ''
    passwordInput.value = ''
})

// Hooking up the open button to make the modal pop up
openModalBtn.addEventListener('click', () =>
{
    // Making the modal appear by adding the active class
    loginModal.classList.add('active')
})

// Hooking up the open button to make the modal close
closeModalBtn.addEventListener('click', () =>
{
    // Making the modal disappear by removing the active class
    loginModal.classList.remove('active')
})

/* Closing modal by clicking the modal when certain conditions are met */
loginBtn.addEventListener('click', () =>
{
    // Checking if one of the input fields are empty
    if (emailInput.value === '' || passwordInput.value === '')
    {
        // If so, let the modal keep the class of active (meaning that it'll stay open)
        loginModal.classList.add('active')
    }
    // Else if none of the input fields are empty
    else if (emailInput.value !== '' && passwordInput.value !== '')
    {
        // Remove the active class (meaning that it'll close)
        loginModal.classList.remove('active')

        // Clearing out the input fields
        emailInput.value = ''
        passwordInput.value = ''
    }
})


// Add Wish Modal //
const addWishModal = document.getElementById('add-wish-modal')
const addWishInput = document.getElementById('add-wish-input')
const addWishBtn = document.getElementById('add-wish-btn')

addWishBtn.addEventListener('click', () =>
{
    addWishInput.value = ''

    if(addWishInput.value === '')
    {
        addWishBtn.style.display = 'none'
    }
})
